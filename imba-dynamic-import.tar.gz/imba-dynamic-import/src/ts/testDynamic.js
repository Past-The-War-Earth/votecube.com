export function helloDynamicImport() {
    return 'Hello from lazy loaded TypeScript!'
}