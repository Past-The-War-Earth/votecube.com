var Imba = require('imba'), _1 = Imba.createElement;
var helloFromLazyModule = require('../ts/test').helloFromLazyModule;
require('babel-polyfill');

var App = Imba.defineTag('App', function(tag){
	
	tag.prototype.testAsync = function (){
		console.log('before call to helloFromLazyModule');
		var helloVal = helloFromLazyModule;
		console.log('after call to helloFromLazyModule');
		return window.alert(helloVal);
	};
	
	tag.prototype.testDynamicImport = function (){
		return this.testAsync();
	};
	
	tag.prototype.render = function (){
		var $ = this.$;
		return this.$open(0).setChildren(
			$[0] || _1('button',$,0,this).on$(0,['tap','testDynamicImport'],this).setText("Test Dynamic Import")
		,2).synced();
	};
});

Imba.mount((_1(App)).end());
