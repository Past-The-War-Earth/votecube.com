# imba-dynamic-import
Example of dynamic import in Imba
