# hello-world-imba

Tiny template for testing out Imba

## Getting started

```bash
# install dependencies
npm install
# start webpack-dev-server and compiler
npm run dev
```
